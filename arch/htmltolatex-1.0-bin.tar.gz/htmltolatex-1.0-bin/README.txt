Linux: Run 'htmltolatex' to see possible options.
Windows: Run java -jar htmltolatex.jar <options>

See 'manual' directory for details on options and configuration.